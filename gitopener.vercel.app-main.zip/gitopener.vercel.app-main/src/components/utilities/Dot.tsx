export default function Dot() {
  return <span className="h-1 w-1 flex-shrink-0 rounded-full bg-accent"></span>;
}
