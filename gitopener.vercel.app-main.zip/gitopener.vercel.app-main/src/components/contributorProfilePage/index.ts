export { default as Introduction } from './Introduction';
export { default as Profile } from './Profile';
export { default as Project } from './Project';
export { default as Projects } from './Projects';
export { default as Skill } from './Skill';
export { default as Skills } from './Skills';
export { default as Socials } from './Socials';
