---
name: Documentation
about: Describe documentation related problem here
title: 'DOC: '
labels: documentation
assignees: ''

---

**What's wrong with the documentation?**

**What's the solution?**

**Submit screenshots**
